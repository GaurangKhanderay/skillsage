
export const QUIZ_API_KEY = Deno.env.get('QUIZ_API_KEY') || '';
export const RESUME_API_KEY = Deno.env.get('RESUME_API_KEY') || '';
export const SUPABASE_URL = Deno.env.get('SUPABASE_URL') || '';
export const SUPABASE_ANON_KEY = Deno.env.get('SUPABASE_ANON_KEY') || '';
